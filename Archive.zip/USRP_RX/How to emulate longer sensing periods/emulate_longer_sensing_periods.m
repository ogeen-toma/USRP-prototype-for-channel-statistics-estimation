
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script shows how longer sensing periods can be emulated without
% having to repeat an experiment. The file energy_values.txt contains the
% energy values measured by the receiver with a sensing period of 10 ms
% when the transmitter transmitted the periods in the TX_periods.txt file.
% By using 1 out of N energy values and discarding the other N-1 values it
% is possible to emulate a sensing period of N * 10 ms.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

% Load the energy values from the file
load('energy_values.txt', '-ascii')

% Original sensing period used in the experiment which produced the energy
% values in the energy_values.txt file
Ts = 0.01; % 10 ms

% Based on the observed energy values, a threshold of 1000 allows a perfect
% sensing performance (all noise levels are below 900 and all signal
% levels are above 1100):
% find(and(energy_values > 900, energy_values < 1100))
decision_threshold = 1000;

% Convert the sequence of energy levels to on/off decisions (every Ts secs)
sensing_decisions = 1*(energy_values >= decision_threshold);

% Emulate all sensing periods from 10 ms to 100 ms in steps of 10 ms
for N = 1:10
    
    % Selectively discard the sensing decisions to emulate the desired Ts
    this_N_sensing_decisions = sensing_decisions(1:N:end);

    % Find the sensing events where the channel state changes (these points
    % will indicate the beginning/end of idle/busy periods)
    transition_points = 1 + find(xor(this_N_sensing_decisions(1:end-1), this_N_sensing_decisions(2:end)));

    % Calculate the number of sensing events in each period
    nof_sensing_events = transition_points(2:end) - transition_points(1:end-1);

    % Assuming that the channel sensing started in an idle state, the first
    % element will be a busy period, which can be discarded (to start with
    % an idle period)
    nof_sensing_events(1) = [];

    % Calculate the period durations
    period_durations = nof_sensing_events * N * Ts;

    % Reshape the vector to the standard format
    period_durations = reshape(period_durations', 2, length(period_durations)/2)';

    % Save the detected periods to a file (Note: It will have one row less
    % than TX_periods.txt as the first pair was discarded)
    dlmwrite(sprintf('RX_periods_Ts_%.3d_ms.txt', N * Ts * 1000), period_durations, 'delimiter', '\t', 'precision', '%.6f')

end
